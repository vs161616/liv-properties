import "./App.css";
import { Main } from "./Component/Main";
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <div className="MainBg">
      <Main />
    </div>
  );
}

export default App;
